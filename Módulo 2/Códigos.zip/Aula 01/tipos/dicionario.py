aluno = {
    'nome': 'Pedro', 
    'nota': 9.2,
    'atibo': True
}

# Hash table
print(type(aluno))
print(aluno['nome'])
print(aluno['nota'])