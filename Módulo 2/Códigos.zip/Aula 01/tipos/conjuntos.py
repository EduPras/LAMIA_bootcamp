# Similar to Set in cpp
print({1,2,3})
print(type({1,2,3}))
x = {1,2,3,3,3,3}
print(len(x))

