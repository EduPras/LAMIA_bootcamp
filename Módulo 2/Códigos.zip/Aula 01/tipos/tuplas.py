nomes = ('Ana', 'Bia', 'Gui', 'Ana')
print(type(nomes))
print('Bia' in nomes)

print(nomes[0])
# Slices
print(nomes[1:3])
print(nomes[1:])
print(nomes[:-1])

print(nomes)