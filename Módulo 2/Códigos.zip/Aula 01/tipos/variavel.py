
a = 3
b = 4.4

print(a+b)

texto = 'sua idade é... '
idade = 23

# print(texto + str(idade))
print(f'{texto} {idade}')

print(3*'bom dia')

# const = UPPER CASE
PI = 3.14

# input as a function
r = float(input("Informe o raio: "))
print(f'A área da circ é {pow(r,2)*PI}')