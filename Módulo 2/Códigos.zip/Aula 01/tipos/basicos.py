print(type(1))  
print(type(1.1))  
print(type('texto'))  
print(type(True))  