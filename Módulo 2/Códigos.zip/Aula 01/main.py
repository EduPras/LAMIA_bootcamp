#!python3

# import pacote.sub.arquivo
# from tipos import variavel
# from tipos import basicos
# from tipos import lista
# import tipos.tuplas
# import tipos.conjuntos
# import tipos.dicionario
# import operadores.unarios
# import operadores.aritmeticos
# import operadores.relacionais
# import operadores.atribuicao
# import operadores.logicos
# import operadores.ternario
# import controle.if_1
# import controle.if_2
# import controle.for_1
# import controle.while_1
import controle.outros_exemplos