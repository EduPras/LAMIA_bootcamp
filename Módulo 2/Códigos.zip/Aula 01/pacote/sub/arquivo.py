#!python3

print(__name__)