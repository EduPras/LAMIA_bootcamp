x = 10
y = 3


print(x+y)
print(x-y)
print(x*y)
print(x/y)
print(x%y)

par = 34
impar = 33

print(par % 2 == 0)
print(impar % 2 == 1)