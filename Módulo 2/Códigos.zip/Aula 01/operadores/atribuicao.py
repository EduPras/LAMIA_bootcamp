resultado = 2
print(resultado)

resultado = 'teste'
print(resultado)

resultado = 2
resultado += 3
resultado -= 1
resultado *= 4
resultado /= 2
resultado %= 6
print(resultado)