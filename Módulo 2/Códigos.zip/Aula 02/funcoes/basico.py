def saudacao(nome = 'Pessoa', idade = 20):
    print(f'Bom dia, {nome} vc tem {idade} anos!')

# def saudacao():
#     print('Opa, bom!')

def soma_e_multi(a, b, x):
    return a + b * x

if __name__ == '__main__':
    saudacao('Ana', idade=30)