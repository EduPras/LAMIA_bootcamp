from funcoes import basico

# basico.saudacao('Maria')
# basico.saudacao('João', 33)
# basico.saudacao()

# a = basico.soma_e_multi(x=10, a=2, b=3)
# print(a)

from funcoes import args

# s = args.soma(1,2,3,4,5,6,6,6,7,7, 1)
# print(s)

# a = args.resultado_final(nome='Pedro', nota=7.3)
# print(a)

# from funcoes import functional
# from funcoes import map_reduce
# from funcoes import lambdas
# from funcoes import comprehension

# from oo import produto
# from oo import heranca
from oo import membros